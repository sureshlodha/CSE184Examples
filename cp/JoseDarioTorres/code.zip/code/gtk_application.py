#necessary imports for GTK+
import gi 
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk


"""
    ---PREAMBLE---

Requirements to run program:
	In order to run the program provided, GTK+ (otherwise known as GTK+3) should be 
installed along with dependencies (such as pyObject). I completed this assignment on
a machine with Windows 10. As a result, I followed the instruction for a Windows 
machine (SEE NOTE BELOW)

	Additionally, they program can only be run in Python3. Finally, note it is not a 
Jupyter Notebook file, simply a python file and as such must be run accordingly. 

-----NOTE-----
Following instrucitons to install on windows required installing jhbuild (to handle and 
   automatically install dependencies). However, I was unable to install jhbuild on my
   machine as instructions were rather unclear. 

As a result, I attempted to install everything fresh and try again using an external 
   drive with an Ubuntu Operating Sys. Things progressed farther (I almost managed
   to install jhbuild), but I encountered another problem regarding python version 
   and found it etremely difficult to overcome.
   
Finally, I found an alternative solution using MSYS MINGQ64. Using the aforementioned 
   shell, I was able to install pyObject and GTK+. However, I could not then figure out 
   how to add the MSYS path to anaconda or Jupyter Notebook. Thus Jupyter Notebook could
   not find GTK+ and MINGW64 could not find the other modules (like pandas). Thus the program
   ONLY requires that GTK+ and its dependencies be installed to run.


"""


#Temporary data for proof of concept
cause_of_death = [("Disease of heart", 635260, 23.1, -1.8, 1.6),
                  ("Malignant neoplasms", 598038, 21.8, -1.7, 1.4),
                  ("Accidents (unintentional injuries)", 161374, 5.9, 9.7, 2.1),
                  ("Chronic lower respiratory diseases", 154596, 5.6, -2.4, 1.2),
                  ("Cerebrovascular diseases", 142142, 5.2, -.8, 1.0),
                  ("Alzheimer’s disease", 116103, 4.2, 3.1, .7),
                  ("Diabetes mellitus", 80058, 2.9, -1.4, 1.5),
                  ("Influenza and pneumonia", 51537, 1.9, -11.2, 1.3),
                  ("Nephritis, nephrotic syndrome and nephrosis", 50046, 1.8, -2.2, 1.4),
                  ("Intentional self-harm", 44965, 1.6, 1.5, 3.6),
                  ("Septicemia", 40613, 1.5, -2.7, 1.2),
                  ("Chronic liver disease and cirrhosis", 40545, 1.5, -.9, 1.9),
                  ("Essential hypertension and hypertensive renal disease", 33246, 1.2, 1.2, 1.1),
                  ("Parkinson’s disease", 29697, 1.1, 3.9, 2.3),
                  ("Pneumonitis due to solids and liquids", 19715, .7, -1.9, 1.8)]

#Definng our own Gtk.Window object with desired fields. This woudl in the long run
#   allow us to create multiple windows and swap between them accordingly based on
#   our desired program
class Application (Gtk.Window):

    #Defining the constructor for our window object
    def __init__(self):
        
        #call the Gtk.Window constructor to begin our initialization of our window
        #   and set default border width.
        Gtk.Window.__init__(self, title="See Data")
        self.set_border_width(10)
        
        #Define the overlaying container (of type box) That will hold all of the 
        #    widgets on the page. Then add the container to the window.
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.add(vbox)

        #Define GTK stack to only display one child widget at a given time. Here
        #   we define it, give it a tranisition type and transition time.
        vstack = Gtk.Stack()
        vstack.set_transition_type(Gtk.StackTransitionType.CROSSFADE)
        vstack.set_transition_duration(500)

        #We create the ListStore that will hold the data from the above list of tuples
        #   by defining what the columns' types will be and populate it.
        self.liststore = Gtk.ListStore(str, int, float, float, float)
        for cause in cause_of_death:
            self.liststore.append(list(cause))
        
        #Now that the TreeModel has been created and filled with the data, we need to
        #   define a TreeView object to be able to visualize it. First, we instantiate
        #   it. Then we iteratively add the columns (with titles) that we want to see.
        #   Additionally, we add a sort column id, allowing us to sort the entire TreeView
        #   by clicking on a column we want to sort by.
        self.treeview_amount = Gtk.TreeView.new_with_model(self.liststore)
        for i, column_title in enumerate(["Cause", "Number", "% Change from Previous Year", "M:F Ratio"]):
            renderer = Gtk.CellRendererText()
            column = Gtk.TreeViewColumn(column_title, renderer, text=i)
            column.set_sort_column_id(i)
            self.treeview_amount.append_column(column)
        #Finished with the normal TreeView

        #Well, what if we want to filter? In order to do that, we have to define a GTK Filter
        #   object. This Filter acts as an "in-between" layer hiding specifc points of data
        #   based on a filter function written by us. Here are the steps to creating such a masterpiece:

        #first define another box container to hold all the contents. We could use a grid, listbox, or even
        #   another stack, but we're going to keep it simple
        self.filter_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)

        #We are going to create another list store with out filter options. The filtering could be selected via 
        #   any of the button types, or anything that sends out a "changed" signal. However, we are gonna use a
        #   dropdown select. Also, we are going to filter by first letter of cause of death in the above list. In 
        #   order to make the dropdown menu, first we have to ake the option in the form of a TreeModel
        filter_choice = Gtk.ListStore(str)
        filter_choice.append(["No Filter"])
        filter_choice.append(["A"])
        filter_choice.append(["C"])
        filter_choice.append(["D"])
        filter_choice.append(["E"])
        filter_choice.append(["I"])
        filter_choice.append(["M"])
        filter_choice.append(["N"])
        filter_choice.append(["P"])
        filter_choice.append(["S"])

        #Now we define our ComboBox using the ListStore we defined above and connect it to a "changed" signal, allowing
        #   us to respond when the user changes the filter type. We use GTK renderer (just like we did with the first
        #   TreeView). Finally, we pack the renderer and finish packing the ComboBox into our overall box.
        filter_combo = Gtk.ComboBox.new_with_model(filter_choice)
        filter_combo.connect("changed", self.filter_change)
        renderer_text = Gtk.CellRendererText()
        filter_combo.pack_start(renderer_text, True)
        filter_combo.add_attribute(renderer_text, "text", 0)
        self.filter_box.pack_start(filter_combo, False, False, 0)

        #Now we are going to make the "in-between" layer: the Filter. Despite the naming I chose, self.filter is not the Filter
        #   Object, rather it's what we are gonna filter by. The self.causefilter is our filter object. We initialize it with our
        #   filter function. Then we create a new TreeView object just like we did prior. Note that the same TreeModel can be used 
        #   for multiple TreeView objects (regardless of filter) This allows us to display the same data differently per TreeView.
        #   Finally, we pack the TreeView into our second box, along with out filter ComboBox
        self.filter = None
        self.causefilter = self.liststore.filter_new()
        self.causefilter.set_visible_func(self.filter_func)
        self.treeview_filter = Gtk.TreeView.new_with_model(self.causefilter)
        for i, column_title in enumerate(["Cause", "Number", "% Change from Previous Year", "M:F Ratio"]):
            renderer = Gtk.CellRendererText()
            column = Gtk.TreeViewColumn(column_title, renderer, text=i)
            self.treeview_filter.append_column(column)
        self.filter_box.pack_end(self.treeview_filter, True, True, 0)

        #Our final child in the stack is going to be a button allowing us to select a file from the computer, then
        #   text displaying the absolute path to said file. This is done but setting a button to start a FileChooser
        #   dialog via its "clicked function". Additionally, we create a label (that will display the path) and pack 
        #   a thir and final box. 
        #NOTE: selecting a file will not do anything as I was unable to figure out how to get Pandas to import on 
        # MingW-w64. So this is more of a proof of concept of what COULD be done with less ineptitude.
        file_select_button = Gtk.Button(label="Choose File")
        file_select_button.connect("clicked", self.on_clicked)
        self.path_label = Gtk.Label(label="")
        self.tempbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        self.tempbox.pack_start(file_select_button, False, False, 10)
        self.tempbox.pack_end(self.path_label, False, False, 0)

        #Finally! All of our boxes are created and filled. Now we place each box into the stack and title them appropriately.        
        vstack.add_titled(self.treeview_amount, "cod", "Cause of Death (2016)")
        vstack.add_titled(self.filter_box, "codf", "Cause of Death (Filtered)")
        vstack.add_titled(self.tempbox, "ff", "From File")

        #Then we initilize our stack switch, the object responsible for switching between children of the stacc and we pack the 
        #   stack into our box that holds everything (boxception).
        stack_switch = Gtk.StackSwitcher()
        stack_switch.set_stack(vstack)
        vbox.pack_start(stack_switch, True, True, 0)
        vbox.pack_start(vstack, True, True, 0)

    #This is the function that handles when the user changes the filter option. What we are doing is extracting the label from the
    #   selection, redefining the filter option to said label (or None if they don't want a filter) and refiltering. Because the 
    #   ComboBox has an underlying TreeModel structure, we select it using the tree_iter, which in essence marks the row, then selecting
    #   the appropriate column.
    def filter_change(self, combo):
        tree_iter = combo.get_active_iter()
        if tree_iter is not None:
            model = combo.get_model()
            sort = model[tree_iter][0]
            print("Selected: sort by:%s" % sort)
            if sort == "No Filter":
                self.filter = None
            else:
                self.filter = sort
            self.causefilter.refilter()
    
    #Here we define the function that the Filter object will use to filter the list. In our case, we want it to display the Causes of Death that
    #   begin with the selected letter. Thus we check the letter by checking at the current row at the first column, i.e. the name. Then we simply
    #   compare the first char and return the appropriate bool.
    def filter_func(self, model, iter, data):
        if self.filter is None or self.filter == "None":
            return True
        else:
            return model[iter][0][0] == self.filter
    
    #Function for starting and interpreting the fileChooser dialog
    def on_clicked(self, widget):
        action = Gtk.FileChooserAction.OPEN

        #First we define the popup dialog with a title and parent, which would be 
        #   itslef, since it is self contained. Then we add the buttons we want on
        #   it and the response that they will each send. 
        dialog = Gtk.FileChooserDialog(title="Please Select File", parent=self,
                 action=action)
        dialog.add_buttons(Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
                 Gtk.STOCK_OPEN, Gtk.ResponseType.OK)
        
        #Here we call a dubroutine to add the different filter options. In this case we 
        #   use filetypes.
        self.add_any_filter(dialog)

        #Next we popup the dialog we created and wait for a response. If we recieve an OK
        #   response, we proceed with the next step for the file. Otherwise, nothing happnes
        #   we can print a message to that effect.
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            self.interpret_file(dialog.get_filename())
        elif response == Gtk.ResponseType.CANCEL:
            print ("CANCELED")
        
        #Lastly, we close the dialog once we are done with it
        dialog.destroy()
    
    #We create four filters (for .csv, .pdf, .txt, and None) and we do so by
    #   selecting files that end in each respective ending. We add the different
    #   filters and presto.
    def add_any_filter(self, dialog):
        filter_any = Gtk.FileFilter()
        filter_any.set_name("Any file")
        filter_any.add_pattern("*")
        dialog.add_filter(filter_any)

        filter_csv = Gtk.FileFilter()
        filter_csv.set_name("CSV")
        filter_csv.add_pattern("*.csv")
        dialog.add_filter(filter_csv)

        filter_pdf = Gtk.FileFilter()
        filter_pdf.set_name("PDF")
        filter_pdf.add_pattern("*.pdf")
        dialog.add_filter(filter_pdf)

        filter_txt = Gtk.FileFilter()
        filter_txt.set_name("Text")
        filter_txt.add_pattern("*.txt")
        dialog.add_filter(filter_txt)

    #Here is where I'd put my file reading function... IF I HAD ONE! But since this is just
    #   a proof of concept, instead we just get the label from the constructor and replace 
    #   the text
    def interpret_file(self, path):
        self.path_label.set_text(str(path))

#Now that our window is defined, we create an instance of it, add the option to close it, 
#   display it, and run the main loop. Done, finally, lets get some food...
window = Application()
window.connect("destroy", Gtk.main_quit)
window.show_all()
Gtk.main()