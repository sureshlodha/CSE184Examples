Requirements to run program:
	In order to run the program provided, GTK+ (otherwise known as GTK+3) should be 
installed along with dependencies (such as pyObject). I completed this assignment on
a machine with Windows 10. As a result, I followed the instruction for a Windows 
machine (SEE NOTE BELOW)

	Additionally, they program can only be run in Python3. Finally, note it is not a 
Jupyter Notebook file, simply a python file and as such must be run accordingly. 

-----NOTE-----
Following instrucitons to install on windows required installing jhbuild (to handle and 
   automatically install dependencies). However, I was unable to install jhbuild on my
   machine as instructions were rather unclear. 

As a result, I attempted to install everything fresh and try again using an external 
   drive with an Ubuntu Operating Sys. Things progressed farther (I almost managed
   to install jhbuild), but I encountered another problem regarding python version 
   and found it etremely difficult to overcome.
   
Finally, I found an alternative solution using MSYS MINGQ64. Using the aforementioned 
   shell, I was able to install pyObject and GTK+. However, I could not then figure out 
   how to add the MSYS path to anaconda or Jupyter Notebook. Thus Jupyter Notebook could
   not find GTK+ and MINGW64 could not find the other modules (like pandas). Thus the program
   ONLY requires that GTK+ and its dependencies be installed to run.

