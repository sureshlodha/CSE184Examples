'''
Source: https://build-system.fman.io/pyqt5-tutorial
'''

from PyQt5.QtWidgets import QApplication, QLabel
from PyQt5.QtGui import *
if __name__ == '__main__':
    '''
    This is a requirement of Qt: Every GUI app must have exactly one instance of
    QApplication.
    '''
    main_app = QApplication([])

    '''
    Here we will create a simple label
    '''
    label = QLabel('Hello World!')

    '''
    We will change the font of the text in the lebel here
    '''
    label.setFont(QFont('Times',16))

    '''
    No we will set the label to be shown
    '''
    label.show()

    '''
    Here we will hand control over to Qt and it will run the application
    '''
    main_app.exec()
