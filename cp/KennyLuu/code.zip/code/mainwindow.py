from PyQt5.QtWidgets import *
from PyQt5 import uic

from scrape import get_menu

class MainWindow(QMainWindow):
    """
    This class is the container of the widget it, initializes the widgets
    It inherits from QMainWindow
    """
    def __init__(self, parent=None):

        # Here we will call QMainWindow's __init__ function to initialize the MainWindow
        super().__init__()

        # We will load the UI file which we just created in QtCreator
        uic.loadUi('mainwindow.ui', self)

        self.setWindowTitle('Dining Hall Food')

        """
        this makes the comboBox unclickable until we enable it when no
        there's text in it
        """
        self.comboBox.setDisabled(True)

        """
        We connect this push button to the function get_dh() when the button is
        pressed
        """
        self.pushButton.pressed.connect(self.get_dh)

        # When the comboBox is activated we will call the function print_dh()
        self.comboBox.activated.connect(self.print_dh)

    def get_dh(self):
        self.dh_dict = get_menu()
        for key in self.dh_dict:
            # Here we will add each item to the comboBox
            self.comboBox.addItem(' '.join(key.split()[0:-2]), key)

        # Here we will append text to the text box
        self.textBrowser.append('Please Select a Dining Hall')

        # We will now let the comboBox be clickable
        self.comboBox.setDisabled(False)

    def print_dh(self):
        self.textBrowser.clear()
        self.textBrowser.append(self.comboBox.currentText())
        meals = self.dh_dict[self.comboBox.currentData()]
        for meal in meals:
            self.textBrowser.append('--------------------------')
            self.textBrowser.append(meal)
            for item in meals[meal]:
                self.textBrowser.append('\t'+item)

if __name__ == '__main__':
    app = QApplication([])
    main = MainWindow()
    main.show()
    app.exec()
