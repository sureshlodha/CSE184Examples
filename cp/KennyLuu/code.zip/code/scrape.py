from bs4 import BeautifulSoup
import requests
import urllib
import multiprocessing
import threading

def get_menu():
    dh_dict = {}
    url = 'https://nutrition.sa.ucsc.edu/'
    rsp = requests.get(url)
    main_page = BeautifulSoup(rsp.text, 'html.parser')
    options = main_page.find_all('option')
    threads = []
    for opt in options:
        if(len(opt['value']) == 0):
            continue
        if(opt.text.split()[-1] != 'Hall'):
            continue
        threads.append(threading.Thread(target=f, args=(opt, dh_dict)))
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()
    return dh_dict

def f(opt, dh_dict):
    url = 'https://nutrition.sa.ucsc.edu/'
    food_dict = {}
    new_url = url+opt['value']
    rsp = urllib.request.urlopen(new_url)
    menu = BeautifulSoup(rsp, 'html.parser')
    meal = menu.find_all('frame', {'title':'main content window'})
    new_url = url+meal[0]['src']
    rsp = urllib.request.urlopen(new_url)
    menu = BeautifulSoup(rsp, 'html.parser')
    divs = menu.find_all('div', {'class':'menusampmeals'})
    td = menu.find_all('td', {'valign':'top', 'width':'50%'})
    for i, a in enumerate(td):
        spans = a.find_all('span', {'style':'color: #000000'})
        foods = []
        for span in spans:
            if(len(span.text) > 1):
                foods.append(span.text)
        food_dict.update({divs[i].text:foods})
    dh_dict.update({opt.text:food_dict})

if __name__ == '__main__':
    x = get_menu()
    print(x)
