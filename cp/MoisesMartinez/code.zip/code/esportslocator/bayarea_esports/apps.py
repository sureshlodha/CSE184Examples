from django.apps import AppConfig


class BayareaEsportsConfig(AppConfig):
    name = 'bayarea_esports'
