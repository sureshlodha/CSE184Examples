con_str = ''
