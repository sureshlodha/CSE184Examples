
# look at configR_template.py for more info

client_id = None
client_secret = None
username = None
password = None
user_agent = "testing"  # can be anything

submitSub = None  # optional
